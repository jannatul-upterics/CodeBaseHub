@extends('layouts.app')

@section('title', 'Policies & Terms | Vocabot Privacy, Cookies & Security')
@section('description', 'Review Vocabot policies regarding data privacy, terms of service, cookie usage, data security, and responsible AI voice technology.')

@section('schema')
<script type="application/ld+json">
{
  "@@context": "https://schema.org",
  "@@type": "BreadcrumbList",
  "itemListElement": [
    {
      "@@type": "ListItem",
      "position": 1,
      "name": "Home",
      "item": "{{ url('/') }}"
    },
    {
      "@@type": "ListItem",
      "position": 2,
      "name": "Policies & Terms",
      "item": "{{ url('/policy') }}"
    }
  ]
}
</script>
@endsection

@section('styles')
    <link rel="stylesheet" href="{{ asset('css/policy.css') }}?v={{ filemtime(public_path('css/policy.css')) }}">
@endsection

@section('content')
<main>
    <section class="policy-hero">
        <div class="hero-glow hero-glow-one"></div>
        <div class="hero-glow hero-glow-two"></div>

        <div class="container hero-content reveal">
            <span class="section-label">
                <i class="ri-shield-check-line"></i>
                VOCABOT POLICIES
            </span>

            <h1>
                Clear policies for
                <span>better conversations.</span>
            </h1>

            <p>
                We believe trust should be simple. This page explains how
                Vocabot handles information, services, cookies, security,
                and the use of AI-powered voice technology.
            </p>

            <div class="hero-meta">
                <span>
                    <i class="ri-calendar-line"></i>
                    Last updated: October 2026
                </span>

                <span>
                    <i class="ri-time-line"></i>
                    Please review periodically
                </span>
            </div>
        </div>
    </section>

    <!-- ================= POLICY NAV ================= -->
    <section class="policy-navigation">
        <div class="container">
            <div class="policy-tabs glass-card">
                <a href="#privacy">
                    <i class="ri-lock-line"></i>
                    <span>Privacy</span>
                </a>
                <a href="#terms">
                    <i class="ri-file-text-line"></i>
                    <span>Terms</span>
                </a>
                <a href="#cookies">
                    <i class="ri-database-2-line"></i>
                    <span>Cookies</span>
                </a>
                <a href="#security">
                    <i class="ri-shield-keyhole-line"></i>
                    <span>Security</span>
                </a>
                <a href="#ai-usage">
                    <i class="ri-robot-line"></i>
                    <span>AI Usage</span>
                </a>
                <a href="#contact-policy">
                    <i class="ri-mail-line"></i>
                    <span>Contact</span>
                </a>
            </div>
        </div>
    </section>

    <!-- ================= POLICY CONTENT ================= -->
    <section class="policy-section">
        <div class="container policy-layout">
            <!-- Sidebar -->
            <aside class="policy-sidebar glass-card">
                <span class="sidebar-title">ON THIS PAGE</span>
                <a href="#privacy" class="sidebar-link active"><span>01</span> Privacy Policy</a>
                <a href="#terms" class="sidebar-link"><span>02</span> Terms of Service</a>
                <a href="#cookies" class="sidebar-link"><span>03</span> Cookie Policy</a>
                <a href="#security" class="sidebar-link"><span>04</span> Data & Security</a>
                <a href="#ai-usage" class="sidebar-link"><span>05</span> AI & Voice Usage</a>
                <a href="#contact-policy" class="sidebar-link"><span>06</span> Contact</a>
            </aside>

            <!-- Main Content -->
            <div class="policy-content">
                <!-- Privacy -->
                <article class="policy-card glass-card reveal" id="privacy">
                    <div class="policy-number">01</div>
                    <div class="policy-heading">
                        <span class="policy-icon"><i class="ri-lock-line"></i></span>
                        <div>
                            <span class="small-label">PRIVACY</span>
                            <h2>Privacy Policy</h2>
                        </div>
                    </div>
                    <p>
                        Vocabot is designed to help businesses manage
                        customer conversations using AI-powered voice
                        technology. This section describes the general
                        approach we take when handling information.
                    </p>

                    <h3>Information we may process</h3>
                    <p>
                        Depending on how Vocabot is used, information may
                        include contact details, account information,
                        conversation data, call metadata, appointment
                        information, and technical information required
                        to operate the service.
                    </p>

                    <h3>How information is used</h3>
                    <ul>
                        <li>To provide and operate Vocabot services.</li>
                        <li>To process customer conversations and requests.</li>
                        <li>To maintain service reliability and security.</li>
                        <li>To provide support and communicate with customers.</li>
                        <li>To improve service performance and functionality.</li>
                        <li>To comply with applicable legal obligations.</li>
                    </ul>

                    <h3>Information sharing</h3>
                    <p>
                        We do not treat customer information as a product
                        to be sold. Information may be shared with service
                        providers that help us operate the platform, where
                        necessary and subject to appropriate contractual
                        and security controls.
                    </p>

                    <h3>Data retention</h3>
                    <p>
                        Information may be retained for as long as needed
                        to provide the service, meet contractual
                        requirements, resolve disputes, maintain security,
                        or satisfy applicable legal obligations.
                    </p>
                </article>

                <!-- Terms -->
                <article class="policy-card glass-card reveal" id="terms">
                    <div class="policy-number">02</div>
                    <div class="policy-heading">
                        <span class="policy-icon"><i class="ri-file-text-line"></i></span>
                        <div>
                            <span class="small-label">SERVICE TERMS</span>
                            <h2>Terms of Service</h2>
                        </div>
                    </div>
                    <p>
                        These terms describe the general conditions under
                        which businesses may access and use Vocabot.
                    </p>

                    <h3>Use of the service</h3>
                    <p>
                        Customers are responsible for using Vocabot in
                        accordance with applicable laws, regulations,
                        contractual obligations, and their own customer
                        communication requirements.
                    </p>

                    <h3>Account responsibility</h3>
                    <p>
                        Customers are responsible for maintaining the
                        confidentiality of account credentials and for
                        activities performed through their account.
                    </p>

                    <h3>Customer content</h3>
                    <p>
                        Customers remain responsible for content,
                        instructions, recordings, business information,
                        and other material supplied to or processed by
                        the service.
                    </p>

                    <h3>Acceptable use</h3>
                    <ul>
                        <li>Do not use the service for unlawful activities.</li>
                        <li>Do not attempt to compromise platform security.</li>
                        <li>Do not intentionally disrupt service availability.</li>
                        <li>Do not misuse automated calling capabilities.</li>
                        <li>Do not use Vocabot to deceive or impersonate individuals.</li>
                    </ul>

                    <h3>Service changes</h3>
                    <p>
                        Vocabot may update, modify, improve, or discontinue
                        features as the platform evolves. Material changes
                        to applicable contractual terms will be communicated
                        through appropriate channels.
                    </p>
                </article>

                <!-- Cookies -->
                <article class="policy-card glass-card reveal" id="cookies">
                    <div class="policy-number">03</div>
                    <div class="policy-heading">
                        <span class="policy-icon"><i class="ri-database-2-line"></i></span>
                        <div>
                            <span class="small-label">WEBSITE TECHNOLOGY</span>
                            <h2>Cookie Policy</h2>
                        </div>
                    </div>
                    <p>
                        Vocabot may use cookies and similar technologies
                        to support website functionality, understand
                        usage patterns, and improve the experience.
                    </p>

                    <h3>Essential cookies</h3>
                    <p>
                        Some cookies may be required for basic website
                        functionality, security, or user preferences.
                    </p>

                    <h3>Analytics</h3>
                    <p>
                        Where analytics technologies are used, they may
                        help us understand aggregate website activity,
                        such as pages visited and general interaction
                        patterns.
                    </p>

                    <h3>Managing cookies</h3>
                    <p>
                        Most modern browsers allow users to control or
                        delete cookies through browser settings. Disabling
                        certain cookies may affect some website functions.
                    </p>
                </article>

                <!-- Security -->
                <article class="policy-card glass-card reveal" id="security">
                    <div class="policy-number">04</div>
                    <div class="policy-heading">
                        <span class="policy-icon"><i class="ri-shield-keyhole-line"></i></span>
                        <div>
                            <span class="small-label">DATA PROTECTION</span>
                            <h2>Data & Security</h2>
                        </div>
                    </div>
                    <p>
                        Security is an important part of operating an
                        AI-powered customer conversation platform.
                        Vocabot uses reasonable technical and organizational
                        measures intended to protect information.
                    </p>

                    <h3>Security measures</h3>
                    <ul>
                        <li>Access controls and authentication mechanisms.</li>
                        <li>Secure communication technologies.</li>
                        <li>Monitoring and operational safeguards.</li>
                        <li>Restricted access to information where appropriate.</li>
                        <li>Security practices designed to reduce unauthorized access.</li>
                    </ul>

                    <h3>Customer responsibility</h3>
                    <p>
                        Customers should also maintain appropriate security
                        controls for their own accounts, integrations,
                        devices, employees, and systems connected to
                        Vocabot.
                    </p>

                    <h3>Security incidents</h3>
                    <p>
                        If we identify a security incident affecting
                        customer information, we will assess and respond
                        according to applicable legal, contractual, and
                        operational requirements.
                    </p>
                </article>

                <!-- AI Usage -->
                <article class="policy-card glass-card reveal" id="ai-usage">
                    <div class="policy-number">05</div>
                    <div class="policy-heading">
                        <span class="policy-icon"><i class="ri-robot-line"></i></span>
                        <div>
                            <span class="small-label">ARTIFICIAL INTELLIGENCE</span>
                            <h2>AI & Voice Usage</h2>
                        </div>
                    </div>
                    <p>
                        Vocabot uses artificial intelligence and voice
                        technologies to support customer interactions.
                        AI-generated responses are produced based on
                        configured workflows, business information,
                        conversation context, and connected systems.
                    </p>

                    <h3>AI-generated responses</h3>
                    <p>
                        AI responses may occasionally be incomplete,
                        inaccurate, or unsuitable for a particular
                        situation. Businesses should configure workflows,
                        escalation rules, and human handoff processes
                        appropriate to their use case.
                    </p>

                    <h3>Voice conversations</h3>
                    <p>
                        Depending on the deployment, calls may involve
                        automated speech recognition, voice synthesis,
                        conversation processing, call recording, or
                        transcription.
                    </p>

                    <h3>Customer disclosure</h3>
                    <p>
                        Businesses using automated voice agents are
                        responsible for determining what disclosures,
                        notices, permissions, or consent requirements
                        apply to their calls and jurisdictions.
                    </p>

                    <h3>Human escalation</h3>
                    <p>
                        Businesses may configure appropriate escalation
                        paths so that conversations can be transferred
                        to human staff when required.
                    </p>
                </article>

                <!-- Contact -->
                <article class="policy-card contact-policy-card glass-card reveal" id="contact-policy">
                    <div class="policy-number">06</div>
                    <div class="policy-heading">
                        <span class="policy-icon"><i class="ri-mail-line"></i></span>
                        <div>
                            <span class="small-label">GET IN TOUCH</span>
                            <h2>Questions about our policies?</h2>
                        </div>
                    </div>
                    <p>
                        If you have questions about these policies,
                        privacy practices, security, or the use of
                        Vocabot services, contact our team.
                    </p>

                    <a href="mailto:hello@vocabot.ai" class="policy-contact-button">
                        <span>hello@vocabot.ai</span>
                        <i class="ri-arrow-up-right-line"></i>
                    </a>

                    <p class="policy-note">
                        We may update these policies from time to time
                        as our services, technology, and legal requirements
                        evolve.
                    </p>
                </article>
            </div>
        </div>
    </section>
</main>
@endsection

@section('scripts')
    <script src="{{ asset('js/policy.js') }}?v={{ filemtime(public_path('js/policy.js')) }}"></script>
@endsection

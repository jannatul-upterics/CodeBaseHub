<?php
  $logoPath = $themeSettings['logo'] ?? 'images/logo2.webp';
  $logoUrl = str_starts_with($logoPath, 'http') ? $logoPath : asset($logoPath);
  $primaryColor = $themeSettings['primary_color'] ?? '#7c3aed';
  $accentColor = $themeSettings['accent_color'] ?? '#a855f7';
  $backgroundColor = $themeSettings['background_color'] ?? '#070313';
  $textColor = $themeSettings['text_color'] ?? '#ffffff';
  $fontFamily = $themeSettings['font_family'] ?? 'Plus Jakarta Sans';
  $buttonStyle = $themeSettings['button_style'] ?? 'pill';
  $layoutMode = $themeSettings['layout_mode'] ?? 'boxed';
  $navbarStyle = $themeSettings['navbar_style'] ?? 'sticky';
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">

  <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
  <title><?php echo $__env->yieldContent('title', 'Vocabot | 24/7 AI Voice Receptionist for Business'); ?></title>
  <meta name="description" content="<?php echo $__env->yieldContent('description', 'Vocabot is a 24/7 AI voice receptionist that answers customer calls, manages reservations and bookings, answers FAQs, and streamlines business workflows.'); ?>">
  <meta name="robots" content="<?php echo $__env->yieldContent('robots', 'index, follow, max-image-preview:large'); ?>">
  <link rel="canonical" href="<?php echo $__env->yieldContent('canonical', url()->current()); ?>">

  <!-- Author & General Meta -->
  <meta name="author" content="Vocabot">

  <!-- Open Graph / Facebook / Instagram / LinkedIn -->
  <meta property="og:site_name" content="Vocabot">
  <meta property="og:type" content="<?php echo $__env->yieldContent('og_type', 'website'); ?>">
  <meta property="og:locale" content="en_US">
  <meta property="og:title" content="<?php echo $__env->yieldContent('title', 'Vocabot | 24/7 AI Voice Receptionist for Business'); ?>">
  <meta property="og:description" content="<?php echo $__env->yieldContent('description', 'Vocabot is a 24/7 AI voice receptionist that answers customer calls, manages reservations and bookings, answers FAQs, and streamlines business workflows.'); ?>">
  <meta property="og:url" content="<?php echo $__env->yieldContent('canonical', url()->current()); ?>">
  <meta property="og:image" content="<?php echo e($logoUrl); ?>">
  <meta property="og:image:secure_url" content="<?php echo e($logoUrl); ?>">
  <meta property="og:image:type" content="image/png">
  <meta property="og:image:width" content="1200">
  <meta property="og:image:height" content="630">
  <meta property="og:image:alt" content="Vocabot - 24/7 AI Voice Receptionist for Business">

  <!-- X (Twitter) Card -->
  <meta name="twitter:card" content="summary_large_image">
  <meta name="twitter:site" content="<?php echo $__env->yieldContent('twitter_site', '@vocabot'); ?>">
  <meta name="twitter:creator" content="<?php echo $__env->yieldContent('twitter_creator', '@vocabot'); ?>">
  <meta name="twitter:title" content="<?php echo $__env->yieldContent('title', 'Vocabot | 24/7 AI Voice Receptionist for Business'); ?>">
  <meta name="twitter:description" content="<?php echo $__env->yieldContent('description', 'Vocabot is a 24/7 AI voice receptionist that answers customer calls, manages reservations and bookings, answers FAQs, and streamlines business workflows.'); ?>">
  <meta name="twitter:image" content="<?php echo e($logoUrl); ?>">
  <meta name="twitter:image:alt" content="Vocabot - 24/7 AI Voice Receptionist for Business">
  <meta name="twitter:domain" content="<?php echo e(parse_url(url('/'), PHP_URL_HOST) ?? 'vocabot.ai'); ?>">
  <meta name="twitter:url" content="<?php echo $__env->yieldContent('canonical', url()->current()); ?>">

  <meta name="theme-color" content="<?php echo e($backgroundColor); ?>">

  <link rel="icon" href="<?php echo e($logoUrl); ?>">
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@400;500;600;700;800&family=Lato:wght@300;400;500;600;700;800;900@if(!empty($fontFamily) && !in_array($fontFamily, ['Plus Jakarta Sans', 'Lato']))&family=<?php echo e(str_replace(' ', '+', $fontFamily)); ?>:wght@400;500;600;700@endif&display=swap" rel="stylesheet">
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/remixicon@4.6.0/fonts/remixicon.css">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css">

  <!-- Global Structured Data: Organization & WebSite -->
  <script type="application/ld+json">
  {
    "@context": "https://schema.org",
    "@graph": [
      {
        "@type": "Organization",
        "@id": "<?php echo e(url('/')); ?>#organization",
        "name": "Vocabot",
        "url": "<?php echo e(url('/')); ?>",
        "logo": {
          "@type": "ImageObject",
          "url": "<?php echo e(asset($themeSettings['logo'] ?? 'images/logo2.webp')); ?>"
        },
        "email": "hello@vocabot.ai",
        "description": "Vocabot provides 24/7 AI voice receptionists for business call answering, reservations, and customer workflows."
      },
      {
        "@type": "WebSite",
        "@id": "<?php echo e(url('/')); ?>#website",
        "url": "<?php echo e(url('/')); ?>",
        "name": "Vocabot",
        "publisher": {
          "@id": "<?php echo e(url('/')); ?>#organization"
        }
      }
    ]
  }
  </script>

  <?php echo $__env->yieldContent('schema'); ?>
  <?php echo $__env->yieldContent('styles'); ?>
  <link rel="stylesheet" href="<?php echo e(asset('css/footer.css')); ?>?v=<?php echo e(filemtime(public_path('css/footer.css'))); ?>">

  <!-- Theme Settings Managed by CodeBaseHub -->
  <style id="codebasehub-theme-settings">
    :root {
      <?php if(!empty($backgroundColor)): ?>
        --bg: <?php echo e($backgroundColor); ?>;
        --bg-2: <?php echo e($backgroundColor); ?>;
      <?php endif; ?>
      <?php if(!empty($primaryColor)): ?>
        --purple: <?php echo e($primaryColor); ?>;
        --purple-dark: <?php echo e($primaryColor); ?>;
      <?php endif; ?>
      <?php if(!empty($accentColor)): ?>
        --magenta: <?php echo e($accentColor); ?>;
        --violet: <?php echo e($accentColor); ?>;
        --lavender: <?php echo e($accentColor); ?>;
        --border: <?php echo e($accentColor); ?>33;
      <?php endif; ?>
      <?php if(!empty($primaryColor) && !empty($accentColor)): ?>
        --gradient: linear-gradient(135deg, <?php echo e($primaryColor); ?> 0%, <?php echo e($accentColor); ?> 100%);
      <?php endif; ?>
      <?php if(!empty($textColor)): ?>
        --text: <?php echo e($textColor); ?>;
      <?php endif; ?>
      <?php if(!empty($fontFamily)): ?>
        --font-family-theme: '<?php echo e($fontFamily); ?>', 'Plus Jakarta Sans', sans-serif;
      <?php endif; ?>
      <?php if(!empty($layoutMode)): ?>
        <?php if($layoutMode === 'narrow'): ?>
          --container: 960px;
        <?php elseif($layoutMode === 'fluid'): ?>
          --container: 95%;
        <?php else: ?>
          --container: 1180px;
        <?php endif; ?>
      <?php endif; ?>
    }

    
    <?php if(!empty($backgroundColor)): ?>
      html, body {
        background-color: <?php echo e($backgroundColor); ?> !important;
        <?php if(strtolower($backgroundColor) !== '#070313'): ?>
          background: <?php echo e($backgroundColor); ?> !important;
        <?php endif; ?>
      }
    <?php endif; ?>

    
    <?php if(!empty($primaryColor)): ?>
      .page-glow.glow-two {
        background: <?php echo e($primaryColor); ?> !important;
      }
    <?php endif; ?>
    <?php if(!empty($accentColor)): ?>
      .page-glow.glow-one {
        background: <?php echo e($accentColor); ?> !important;
      }
    <?php endif; ?>

    
    <?php if(!empty($fontFamily)): ?>
      body, h1, h2, h3, h4, h5, h6, .btn, .primary-btn, .secondary-btn, .cta-btn, .submit-btn, .navbar, .desktop-nav, .mobile-menu, .nav-btn, input, select, textarea {
        font-family: var(--font-family-theme, 'Plus Jakarta Sans', sans-serif) !important;
      }
    <?php endif; ?>

    
    <?php if(!empty($textColor)): ?>
      body, h1, h2, h3, h4, h5, h6, .brand span {
        color: <?php echo e($textColor); ?>;
      }
    <?php endif; ?>

    
    <?php if(!empty($buttonStyle)): ?>
      <?php
        $radius = match($buttonStyle) {
          'pill' => '999px',
          'rounded' => '8px',
          'square' => '0px',
          default => '999px',
        };
        $cardRadius = match($buttonStyle) {
          'pill' => '22px',
          'rounded' => '14px',
          'square' => '6px',
          default => '22px',
        };
        $inputRadius = match($buttonStyle) {
          'pill' => '14px',
          'rounded' => '8px',
          'square' => '4px',
          default => '14px',
        };
      ?>
      .btn, .primary-btn, .secondary-btn, .cta-btn, .submit-btn, .nav-btn, .filter-btn, .btn-ghost, .mobile-demo {
        border-radius: <?php echo e($radius); ?> !important;
      }
      .glass-card, .problem-card, .feature-card, .sector-card, .integration-card, .audio-card, .roi-card, .contact-card, .step-card, .solution-card {
        border-radius: <?php echo e($cardRadius); ?> !important;
      }
      input, select, textarea, .input-wrap {
        border-radius: <?php echo e($inputRadius); ?> !important;
      }
    <?php endif; ?>

    
    <?php if(!empty($primaryColor) && !empty($accentColor)): ?>
      .btn-primary, .primary-btn, .submit-btn, .cta-btn, .nav-btn, .mobile-demo {
        background: linear-gradient(135deg, <?php echo e($primaryColor); ?> 0%, <?php echo e($accentColor); ?> 100%) !important;
        color: #fff !important;
        border: 1px solid rgba(255, 255, 255, 0.15) !important;
        box-shadow: 0 10px 25px <?php echo e($primaryColor); ?>35 !important;
      }
      .btn-primary:hover, .primary-btn:hover, .submit-btn:hover, .cta-btn:hover, .nav-btn:hover, .mobile-demo:hover {
        box-shadow: 0 14px 32px <?php echo e($primaryColor); ?>55 !important;
        transform: translateY(-1px);
      }
      .btn-ghost, .secondary-btn {
        background: transparent !important;
        color: <?php echo e($textColor); ?> !important;
        border: 1px solid <?php echo e($accentColor); ?> !important;
      }
      .btn-ghost:hover, .secondary-btn:hover {
        background: <?php echo e($accentColor); ?>20 !important;
        border-color: <?php echo e($accentColor); ?> !important;
        color: #fff !important;
      }
    <?php endif; ?>

    
    <?php if(!empty($accentColor)): ?>
      .status-pill {
        background: <?php echo e($accentColor); ?>25 !important;
        color: <?php echo e($accentColor); ?> !important;
        border: 1px solid <?php echo e($accentColor); ?>50 !important;
      }
      .eyebrow {
        background: <?php echo e($accentColor); ?>15 !important;
        border-color: <?php echo e($accentColor); ?>40 !important;
        color: <?php echo e($textColor); ?> !important;
      }
      .live-dot {
        background: <?php echo e($accentColor); ?> !important;
        box-shadow: 0 0 10px <?php echo e($accentColor); ?> !important;
      }
      .waveform i {
        background: <?php echo e($accentColor); ?> !important;
      }
      .brand b, .footer-brand .brand b {
        color: <?php echo e($accentColor); ?> !important;
      }
      .desktop-nav a.active::after, .desktop-nav a:hover::after,
      .mobile-menu a.active::after, .mobile-menu a:hover::after {
        background: <?php echo e($accentColor); ?> !important;
        box-shadow: 0 0 8px <?php echo e($accentColor); ?>80 !important;
      }
      .filter-btn.active {
        background: <?php echo e($accentColor); ?> !important;
        color: #fff !important;
        border-color: <?php echo e($accentColor); ?> !important;
      }
    <?php endif; ?>

    
    <?php if(!empty($accentColor)): ?>
      .glass-card, .problem-card, .feature-card, .sector-card, .integration-card, .audio-card, .roi-card, .contact-card, .solution-card {
        border-color: <?php echo e($accentColor); ?>25 !important;
      }
      .glass-card:hover, .problem-card:hover, .feature-card:hover, .sector-card:hover, .integration-card:hover, .solution-card:hover {
        border-color: <?php echo e($accentColor); ?>80 !important;
        box-shadow: 0 16px 40px <?php echo e($primaryColor ?? '#7c3aed'); ?>25 !important;
      }
    <?php endif; ?>

    
    <?php if(!empty($accentColor)): ?>
      input:focus, textarea:focus, select:focus, .input-wrap:focus-within {
        border-color: <?php echo e($accentColor); ?> !important;
        box-shadow: 0 0 0 3px <?php echo e($accentColor); ?>25 !important;
        outline: none !important;
      }
    <?php endif; ?>

    
    <?php if(!empty($backgroundColor)): ?>
      .footer {
        background: <?php echo e($backgroundColor); ?> !important;
        border-top: 1px solid <?php echo e($accentColor ?? '#a855f7'); ?>25 !important;
      }
      .footer .footer-brand p, .footer .footer-col a {
        color: <?php echo e($textColor ?? '#ffffff'); ?>aa !important;
      }
      .footer .footer-col h3, .footer .footer-brand .brand {
        color: <?php echo e($textColor ?? '#ffffff'); ?> !important;
      }
      .footer .footer-col a:hover {
        color: <?php echo e($accentColor ?? '#a855f7'); ?> !important;
      }
      .footer .socials a {
        color: <?php echo e($accentColor ?? '#a855f7'); ?> !important;
        border-color: <?php echo e($accentColor ?? '#a855f7'); ?>40 !important;
      }
      .footer .socials a:hover {
        background: linear-gradient(135deg, <?php echo e($primaryColor ?? '#7c3aed'); ?> 0%, <?php echo e($accentColor ?? '#a855f7'); ?> 100%) !important;
        color: #fff !important;
        border-color: transparent !important;
      }
    <?php endif; ?>

    
    <?php if(!empty($backgroundColor)): ?>
      .mobile-menu {
        background: <?php echo e($backgroundColor); ?>f5 !important;
        border: 1px solid <?php echo e($accentColor ?? '#a855f7'); ?>40 !important;
        backdrop-filter: blur(20px) !important;
        -webkit-backdrop-filter: blur(20px) !important;
      }
      .mobile-menu a {
        color: <?php echo e($textColor ?? '#ffffff'); ?>cc !important;
      }
      .mobile-menu a:hover, .mobile-menu a.active {
        color: <?php echo e($textColor ?? '#ffffff'); ?> !important;
        background: <?php echo e($accentColor ?? '#a855f7'); ?>20 !important;
      }
    <?php endif; ?>

    
    <?php if(!empty($layoutMode) && $layoutMode === 'fluid'): ?>
      .container {
        width: 95% !important;
        max-width: 100% !important;
      }
    <?php endif; ?>

    
    <?php if(!empty($navbarStyle)): ?>
      <?php if($navbarStyle === 'standard'): ?>
        .navbar {
          position: relative !important;
          top: auto !important;
        }
      <?php elseif($navbarStyle === 'transparent'): ?>
        .navbar {
          background: transparent !important;
          backdrop-filter: none !important;
          -webkit-backdrop-filter: none !important;
          border-bottom: none !important;
        }
        .navbar.scrolled {
          background: rgba(7, 3, 19, 0.85) !important;
          backdrop-filter: blur(18px) !important;
        }
      <?php elseif($navbarStyle === 'sticky'): ?>
        .navbar {
          position: sticky !important;
          top: 0 !important;
        }
      <?php endif; ?>
    <?php endif; ?>

    
    <?php if(!empty($themeSettings['custom_css'])): ?>
      <?php echo $themeSettings['custom_css']; ?>

    <?php endif; ?>
  </style>
</head>

<body>
  <div class="page-glow glow-one"></div>
  <div class="page-glow glow-two"></div>
  <div class="grid-overlay"></div>

  <!-- Shared Header -->
  <?php echo $__env->make('layouts.header', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

  <!-- Page Content -->
  <?php echo $__env->yieldContent('content'); ?>

  <!-- Shared Footer -->
  <?php echo $__env->make('layouts.footer', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>

  <script src="https://code.jquery.com/jquery-3.7.1.min.js"></script>
  <script>window.jQuery || document.write('<script src="<?php echo e(asset('js/jquery.min.js')); ?>"><\/script>')</script>
  <script src="https://cdn.jsdelivr.net/npm/jquery-validation@1.19.5/dist/jquery.validate.min.js"></script>
  <script>window.jQuery && window.jQuery.fn && window.jQuery.fn.validate || document.write('<script src="<?php echo e(asset('js/jquery.validate.min.js')); ?>"><\/script>')</script>
  <?php echo $__env->yieldContent('scripts'); ?>
</body>
</html>

<?php /**PATH D:\Sellyco Promotions\CodeBaseHub\Vocabot\resources\views/layouts/app.blade.php ENDPATH**/ ?>